import 'package:material_ui/material_ui.dart';

import '../../shared/retained_tab_host.dart';
import '../knowledge/knowledge_page.dart';
import '../models/model_file_verifier.dart';
import '../models/models_page.dart';
import '../runtime/model_runtime_manager.dart';
import '../resources/nexus_experience_settings.dart';

/// Keeps model management and the local knowledge library together while
/// creating each feature only when the user first opens its tab.
class LibraryHubPage extends StatelessWidget {
  const LibraryHubPage({
    super.key,
    required this.fileVerifier,
    required this.runtimeManager,
    this.experienceSettings,
  });

  final ModelFileVerifier fileVerifier;
  final ModelRuntimeManager runtimeManager;
  final NexusExperienceSettings? experienceSettings;

  @override
  Widget build(BuildContext context) {
    return RetainedTabHost(
      tabs: const [
        Tab(icon: Icon(Icons.memory_outlined), text: 'النماذج'),
        Tab(icon: Icon(Icons.menu_book_outlined), text: 'المعرفة'),
      ],
      pages: [
        ModelsPage(
          fileVerifier: fileVerifier,
          runtimeManager: runtimeManager,
          experienceSettings: experienceSettings,
        ),
        const KnowledgePage(),
      ],
    );
  }
}
