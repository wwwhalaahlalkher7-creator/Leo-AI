import 'package:material_ui/material_ui.dart';

import '../../shared/retained_tab_host.dart';
import '../agents/agents_page.dart';
import '../orchestration/agent_tasks_page.dart';
import '../runtime/model_runtime_manager.dart';
import '../resources/nexus_experience_settings.dart';

/// Presents task orchestration first and keeps agent configuration one level
/// away without throwing away either page's state when tabs change.
class WorkHubPage extends StatelessWidget {
  const WorkHubPage({
    super.key,
    required this.runtimeManager,
    this.experienceSettings,
  });

  final ModelRuntimeManager runtimeManager;
  final NexusExperienceSettings? experienceSettings;

  @override
  Widget build(BuildContext context) {
    return RetainedTabHost(
      tabs: const [
        Tab(icon: Icon(Icons.task_alt_outlined), text: 'تنفيذ المهام'),
        Tab(icon: Icon(Icons.hub_outlined), text: 'الوكلاء'),
      ],
      pages: [
        AgentTasksPage(
          runtimeManager: runtimeManager,
          experienceSettings: experienceSettings,
        ),
        AgentsPage(
          runtimeManager: runtimeManager,
          showTaskNavigationAction: false,
        ),
      ],
    );
  }
}
