import 'package:material_ui/material_ui.dart';

import '../runtime/core_runtime_card.dart';
import '../runtime/core_runtime_service.dart';
import '../runtime/rust_core_runtime_service.dart';
import '../runtime/model_runtime_manager.dart';
import '../resources/nexus_experience_settings.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({
    super.key,
    this.runtimeService,
    this.runtimeManager,
    this.onOpenChat,
    this.onOpenTasks,
    this.onOpenLibrary,
    this.onOpenDevices,
    this.experienceSettings,
  });

  final CoreRuntimeService? runtimeService;
  final ModelRuntimeManager? runtimeManager;
  final VoidCallback? onOpenChat;
  final VoidCallback? onOpenTasks;
  final VoidCallback? onOpenLibrary;
  final VoidCallback? onOpenDevices;
  final NexusExperienceSettings? experienceSettings;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;
    final primaryAction = runtimeManager == null
        ? _buildPrimaryAction(theme, true)
        : AnimatedBuilder(
            animation: runtimeManager!,
            builder: (context, _) => _buildPrimaryAction(
              theme,
              runtimeManager!.snapshot.isLoaded,
            ),
          );

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 28),
      children: [
        Text(
          'مرحباً بك في NEXUS',
          style: theme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 5),
        Text(
          'مساعدك المحلي لإجاباتك وملفاتك ومهامك.',
          style: theme.textTheme.bodyMedium?.copyWith(
            color: colors.onSurfaceVariant,
          ),
        ),
        if (runtimeManager != null) ...[
          const SizedBox(height: 16),
          if (experienceSettings == null)
            _ModelSessionSummary(manager: runtimeManager!)
          else
            AnimatedBuilder(
              animation: experienceSettings!,
              builder: (context, _) => _ModelSessionSummary(
                manager: runtimeManager!,
                isAdvanced: experienceSettings!.isAdvanced,
              ),
            ),
        ],
        const SizedBox(height: 16),
        primaryAction,
        const SizedBox(height: 12),
        Text(
          'ما الذي تريد إنجازه؟',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 8),
        if (experienceSettings == null)
          _quickActions(isAdvanced: true)
        else
          AnimatedBuilder(
            animation: experienceSettings!,
            builder: (context, _) => _quickActions(
              isAdvanced: experienceSettings!.isAdvanced,
            ),
          ),
        const SizedBox(height: 10),
        if (experienceSettings == null)
          const SizedBox.shrink()
        else
          AnimatedBuilder(
            animation: experienceSettings!,
            builder: (context, _) => experienceSettings!.isAdvanced
                ? Card(
                    clipBehavior: Clip.antiAlias,
                    child: ExpansionTile(
                      leading: Icon(Icons.monitor_heart_outlined, color: colors.primary),
                      title: const Text(
                        'تفاصيل المحرك والتشخيص',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                      subtitle: const Text('حالة الجسر والذاكرة والمحرك الأصلي'),
                      childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                      children: [
                        CoreRuntimeCard(
                          service: runtimeService ?? RustCoreRuntimeService(),
                        ),
                      ],
                    ),
                  )
                : const SizedBox.shrink(),
          ),
        const SizedBox(height: 8),
        Text(
          'تُدار النماذج والبيانات محلياً. تبقى عمليات الاقتران والتنفيذ على الأجهزة الأخرى خاضعة لموافقتك.',
          style: theme.textTheme.bodySmall?.copyWith(
            color: colors.onSurfaceVariant,
            height: 1.45,
          ),
        ),
      ],
    );
  }

  Widget _quickActions({required bool isAdvanced}) {
    return Column(
      children: [
        _QuickActionTile(
          icon: Icons.task_alt_rounded,
          title: isAdvanced ? 'تنفيذ مهمة متعددة الوكلاء' : 'إنجاز مهمة',
          subtitle: isAdvanced
              ? 'حوّل هدفك إلى خطوات موزعة على وكلائك.'
              : 'اكتب ما تريد إنجازه وسيتولى NEXUS تنظيم الخطوات.',
          onTap: onOpenTasks,
        ),
        _QuickActionTile(
          icon: Icons.library_books_outlined,
          title: isAdvanced ? 'النماذج والمعرفة' : 'النماذج والملفات',
          subtitle: isAdvanced
              ? 'استورد نموذجاً محلياً أو افتح قاعدة معرفتك.'
              : 'أضف نموذجاً أو افتح ملفاتك المعرفية.',
          onTap: onOpenLibrary,
        ),
        _QuickActionTile(
          icon: Icons.devices_other_outlined,
          title: isAdvanced ? 'الأجهزة المتصلة' : 'ربط جهاز آخر',
          subtitle: isAdvanced
              ? 'اربط جهازاً آخر وأدر المهام المشتركة.'
              : 'اكتشف جهازاً قريباً أو امسح رمز الدعوة.',
          onTap: onOpenDevices,
        ),
      ],
    );
  }

  Widget _buildPrimaryAction(ThemeData theme, bool modelLoaded) {
    return FilledButton.icon(
      onPressed: modelLoaded ? onOpenChat : onOpenLibrary,
      icon: Icon(
        modelLoaded ? Icons.chat_rounded : Icons.file_download_outlined,
      ),
      label: Text(modelLoaded ? 'ابدأ محادثة' : 'تجهيز نموذج للبدء'),
      style: FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(52),
        textStyle: theme.textTheme.titleMedium?.copyWith(
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _QuickActionTile extends StatelessWidget {
  const _QuickActionTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        minVerticalPadding: 12,
        contentPadding: const EdgeInsetsDirectional.only(
          start: 14,
          end: 10,
          top: 4,
          bottom: 4,
        ),
        leading: CircleAvatar(
          backgroundColor: colors.secondaryContainer,
          foregroundColor: colors.onSecondaryContainer,
          child: Icon(icon),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 3),
          child: Text(subtitle),
        ),
        trailing: const Icon(Icons.chevron_left_rounded),
        onTap: onTap,
      ),
    );
  }
}

class _ModelSessionSummary extends StatelessWidget {
  const _ModelSessionSummary({
    required this.manager,
    this.isAdvanced = true,
  });

  final ModelRuntimeManager manager;
  final bool isAdvanced;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: manager,
      builder: (context, _) {
        final snapshot = manager.snapshot;
        final (icon, title, detail, color) = switch (snapshot.state) {
          ModelSessionState.loaded => (
              Icons.check_circle_outline,
              'النموذج جاهز للمحادثة',
              isAdvanced
                  ? 'محمل على CPU · السياق ${snapshot.contextTokens ?? 0} رمز'
                  : 'يمكنك بدء محادثتك الآن.',
              Theme.of(context).colorScheme.primary,
            ),
          ModelSessionState.loading => (
              Icons.downloading_outlined,
              'جارٍ تحميل النموذج',
              isAdvanced ? snapshot.message : 'يجهّز NEXUS النموذج الآن.',
              Theme.of(context).colorScheme.primary,
            ),
          ModelSessionState.unloading => (
              Icons.hourglass_bottom,
              'جارٍ تفريغ النموذج',
              isAdvanced ? snapshot.message : 'يجري إنهاء الجلسة الحالية.',
              Theme.of(context).colorScheme.secondary,
            ),
          ModelSessionState.switching => (
              Icons.swap_horiz_rounded,
              'جارٍ تبديل النموذج',
              isAdvanced ? snapshot.message : 'يجري التبديل إلى النموذج المطلوب.',
              Theme.of(context).colorScheme.secondary,
            ),
          ModelSessionState.recoveryRequired => (
              Icons.warning_amber_rounded,
              'المحرك يحتاج إلى استعادة',
              snapshot.message,
              Theme.of(context).colorScheme.error,
            ),
          ModelSessionState.readyToLoad => (
              Icons.fact_check_outlined,
              'النموذج اجتاز فحص الجاهزية',
              isAdvanced ? 'الأوزان لم تُحمّل بعد.' : 'سيكمل NEXUS التجهيز تلقائياً.',
              Theme.of(context).colorScheme.primary,
            ),
          ModelSessionState.checking => (
              Icons.manage_search_outlined,
              'جارٍ فحص النموذج',
              snapshot.message,
              Theme.of(context).colorScheme.primary,
            ),
          ModelSessionState.failed => (
              Icons.error_outline,
              'تعذر تجهيز النموذج',
              snapshot.message,
              Theme.of(context).colorScheme.error,
            ),
          ModelSessionState.idle => (
              Icons.memory_outlined,
              'لا يوجد نموذج محمّل',
              isAdvanced
                  ? 'أضف نموذج GGUF من المكتبة لبدء المحادثة المحلية.'
                  : 'أضف نموذجاً للبدء.',
              Theme.of(context).colorScheme.onSurfaceVariant,
            ),
        };

        return Card(
          child: ListTile(
            minVerticalPadding: 12,
            leading: Icon(icon, color: color, size: 28),
            title: Text(
              title,
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(detail),
            ),
            isThreeLine: detail.length > 52,
          ),
        );
      },
    );
  }
}
