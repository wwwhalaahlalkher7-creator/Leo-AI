import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';

import '../../data/local_database.dart';

/// Persists the presentation level without changing runtime permissions.
/// Basic mode is deliberately the default for fresh installations.
class NexusExperienceSettings extends ChangeNotifier {
  NexusExperienceSettings({LocalDatabase? database})
      : _database = database ?? LocalDatabase.instance;

  static const String _key = 'nexus_advanced_options_enabled';

  final LocalDatabase _database;
  bool _advanced = false;
  bool _loaded = false;
  bool _saving = false;
  Future<void>? _loadFuture;

  bool get isAdvanced => _advanced;
  bool get isLoaded => _loaded;
  bool get isSaving => _saving;

  Future<void> load() => _loadFuture ??= _loadInternal();

  Future<void> _loadInternal() async {
    if (_loaded) return;
    try {
      final db = await _database.database;
      final rows = await db.query(
        'app_settings',
        columns: ['value'],
        where: 'key = ?',
        whereArgs: [_key],
        limit: 1,
      );
      _advanced = rows.isNotEmpty && rows.single['value'] == 'true';
    } catch (_) {
      // A preference read failure must never prevent the app from opening.
      // Basic mode is the safe, predictable fallback.
      _advanced = false;
    } finally {
      _loaded = true;
      notifyListeners();
    }
  }

  Future<void> setAdvanced(bool value) async {
    if (!_loaded) await load();
    if (_saving || value == _advanced) return;
    _saving = true;
    notifyListeners();
    try {
      final db = await _database.database;
      await db.insert(
        'app_settings',
        {
          'key': _key,
          'value': value ? 'true' : 'false',
          'updated_at_unix_ms': DateTime.now().millisecondsSinceEpoch,
        },
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      _advanced = value;
    } finally {
      _saving = false;
      notifyListeners();
    }
  }

  Future<void> toggle() async {
    if (!_loaded) await load();
    await setAdvanced(!_advanced);
  }
}
