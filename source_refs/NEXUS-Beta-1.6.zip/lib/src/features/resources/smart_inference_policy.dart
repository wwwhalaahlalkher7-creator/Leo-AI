/// Small deterministic policies for the normal, zero-configuration workflow.
/// The native runtime remains authoritative and enforces its own hard limits.
class SmartInferencePolicy {
  const SmartInferencePolicy._();

  static const int nativeMaxOutputTokens = 1024;
  static const int minimumOutputTokens = 64;

  static const List<String> _detailedIntent = [
    'بالتفصيل',
    'تفصيلي',
    'اشرح',
    'حلل',
    'قارن',
    'خطوة بخطوة',
    'خطة',
    'برمج',
    'اكتب كود',
    'لخص',
    'استخرج',
    'ناقش',
    'الأسباب',
  ];

  /// `manualOverride` is null in normal mode. Advanced mode may supply a
  /// precise value; both paths are clamped to the native API and context.
  static int outputTokenBudget({
    required String prompt,
    required int contextTokens,
    int? manualOverride,
  }) {
    final contextLimit = (contextTokens ~/ 4)
        .clamp(minimumOutputTokens, nativeMaxOutputTokens)
        .toInt();

    if (manualOverride != null) {
      return manualOverride
          .clamp(minimumOutputTokens, contextLimit)
          .toInt();
    }

    final normalized = prompt.trim().toLowerCase();
    final detailed = _detailedIntent.any(normalized.contains);
    final target = switch (normalized.length) {
      <= 90 => detailed ? 512 : 256,
      <= 450 => detailed ? 768 : 512,
      <= 1200 => 768,
      _ => 1024,
    };
    return target.clamp(minimumOutputTokens, contextLimit).toInt();
  }
}
