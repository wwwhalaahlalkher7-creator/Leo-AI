import '../agents/agent_record.dart';
import '../models/model_fit_estimator.dart';
import '../models/model_record.dart';
import '../models/rust_gguf_inspector.dart';
import 'adaptive_inference_policy.dart';
import 'resource_settings.dart';
import 'smart_inference_policy.dart';

/// One deterministic decision facade for the zero-configuration experience.
/// It reuses the existing runtime, retrieval and agent-selection logic; it does
/// not bypass native limits, user approvals, or per-device permissions.
class NexusSmartPolicy {
  const NexusSmartPolicy._();

  static int outputTokenBudget({
    required String prompt,
    required int contextTokens,
    int? advancedOverride,
  }) {
    return SmartInferencePolicy.outputTokenBudget(
      prompt: prompt,
      contextTokens: contextTokens,
      manualOverride: advancedOverride,
    );
  }

  static bool shouldUseKnowledge({
    required String prompt,
    required bool advancedMode,
    required bool advancedKnowledgeEnabled,
  }) {
    if (prompt.trim().startsWith('/')) return false;
    return !advancedMode || advancedKnowledgeEnabled;
  }

  static AdaptiveInferenceRecommendation recommendRuntime({
    required ModelRecord model,
    required int verifiedModelFileBytes,
    required ResourceSnapshot resources,
    required ResourceSettings settings,
    GgufInspection? freshInspection,
  }) {
    return AdaptiveInferencePolicy.recommend(
      model: model,
      verifiedModelFileBytes: verifiedModelFileBytes,
      resources: resources,
      settings: settings,
      freshInspection: freshInspection,
    );
  }

  /// Selects a ready planner using the user's goal and the local agent metadata.
  /// When no clear keyword match exists, list order is retained as a stable
  /// fallback rather than making a random choice.
  static AgentRecord? selectPlanner({
    required String goal,
    required List<AgentRecord> agents,
  }) {
    final ready = agents
        .where((agent) => agent.status == AgentRecordStatus.ready)
        .toList(growable: false);
    if (ready.isEmpty) return null;

    final goalTokens = _tokens(goal);
    var best = ready.first;
    var bestScore = -1;
    for (final agent in ready) {
      final searchable = _normalize(
        '${agent.name} ${agent.description} ${agent.systemPrompt}',
      );
      final score = goalTokens.where((token) => searchable.contains(token)).length;
      if (score > bestScore) {
        best = agent;
        bestScore = score;
      }
    }
    return best;
  }

  static List<String> _tokens(String value) {
    const stopWords = <String>{
      'هذا', 'هذه', 'ذلك', 'تلك', 'الذي', 'التي', 'من', 'في', 'على', 'الى',
      'إلى', 'عن', 'مع', 'ما', 'ماذا', 'كيف', 'هل', 'انا', 'أنا', 'اريد',
      'أريد', 'لي', 'لدي', 'ثم', 'بعد', 'قبل', 'كان', 'تكون', 'يكون',
    };
    return _normalize(value)
        .split(RegExp(r'\s+'))
        .where((token) => token.length >= 3 && !stopWords.contains(token))
        .toList(growable: false);
  }

  static String _normalize(String value) {
    return value
        .toLowerCase()
        .replaceAll(RegExp(r'[\u064B-\u065F\u0670]'), '')
        .replaceAll(RegExp(r'[^\u0600-\u06FFa-z0-9]+'), ' ')
        .trim();
  }
}
