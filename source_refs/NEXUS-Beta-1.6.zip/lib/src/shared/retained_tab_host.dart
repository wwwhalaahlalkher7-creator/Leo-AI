import 'package:material_ui/material_ui.dart';

/// A small tab host that creates feature pages only when first selected and
/// then keeps their state mounted while the user switches between tabs.
class RetainedTabHost extends StatefulWidget {
  const RetainedTabHost({
    super.key,
    required this.tabs,
    required this.pages,
    this.initialIndex = 0,
  }) : assert(tabs.length == pages.length),
       assert(tabs.length > 0),
       assert(initialIndex >= 0 && initialIndex < tabs.length);

  final List<Tab> tabs;
  final List<Widget> pages;
  final int initialIndex;

  @override
  State<RetainedTabHost> createState() => _RetainedTabHostState();
}

class _RetainedTabHostState extends State<RetainedTabHost>
    with SingleTickerProviderStateMixin {
  late final TabController _controller;
  late int _selectedIndex;
  late final Set<int> _visitedPages;

  @override
  void initState() {
    super.initState();
    _selectedIndex = widget.initialIndex;
    _visitedPages = <int>{widget.initialIndex};
    _controller = TabController(
      length: widget.tabs.length,
      vsync: this,
      initialIndex: widget.initialIndex,
    );
  }

  void _selectTab(int index) {
    if (index == _selectedIndex) {
      return;
    }
    setState(() {
      _selectedIndex = index;
      _visitedPages.add(index);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final children = List<Widget>.generate(
      widget.pages.length,
      (index) => _visitedPages.contains(index)
          ? widget.pages[index]
          : const SizedBox.shrink(),
      growable: false,
    );

    return Column(
      children: [
        Material(
          color: Theme.of(context).colorScheme.surface,
          child: TabBar(
            controller: _controller,
            tabs: widget.tabs,
            onTap: _selectTab,
          ),
        ),
        Expanded(
          child: IndexedStack(
            index: _selectedIndex,
            children: children,
          ),
        ),
      ],
    );
  }
}
