import 'dart:async';

import 'package:material_ui/material_ui.dart';

import 'features/dashboard/dashboard_page.dart';
import 'features/devices/device_network_service.dart';
import 'features/devices/devices_page.dart';
import 'features/inference/inference_page.dart';
import 'features/library/library_hub_page.dart';
import 'features/models/model_file_verifier.dart';
import 'features/privacy/privacy_center_page.dart';
import 'features/resources/resource_settings_page.dart';
import 'features/resources/nexus_experience_settings.dart';
import 'features/runtime/core_runtime_service.dart';
import 'features/runtime/model_runtime_manager.dart';
import 'features/runtime/rust_model_runtime_backend.dart';
import 'features/work/work_hub_page.dart';

enum _HomeMenuAction { toggleAdvanced, resourceSettings, privacy }

class NexusHomePage extends StatefulWidget {
  const NexusHomePage({super.key, this.runtimeService});

  final CoreRuntimeService? runtimeService;

  @override
  State<NexusHomePage> createState() => _NexusHomePageState();
}

class _NexusHomePageState extends State<NexusHomePage> {
  int _selectedIndex = 0;
  final Set<int> _visitedPages = <int>{0};
  late final ModelFileVerifier _modelFileVerifier;
  late final ModelRuntimeManager _modelRuntimeManager;
  late final DeviceNetworkService _deviceNetworkService;
  late final NexusExperienceSettings _experienceSettings;
  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    // Keep shared services above the tabs. The lazy IndexedStack below keeps
    // visited stateful pages alive without eagerly allocating every feature.
    _experienceSettings = NexusExperienceSettings();
    unawaited(_experienceSettings.load());
    _modelFileVerifier = LocalModelFileVerifier();
    _deviceNetworkService = DeviceNetworkService();
    _modelRuntimeManager = ModelRuntimeManager(
      verifier: _modelFileVerifier,
      backend: const RustModelRuntimeBackend(),
    );
    _pages = [
      DashboardPage(
        runtimeService: widget.runtimeService,
        runtimeManager: _modelRuntimeManager,
        onOpenChat: () => _selectPage(1),
        onOpenTasks: () => _selectPage(2),
        onOpenLibrary: () => _selectPage(3),
        onOpenDevices: _openDevices,
        experienceSettings: _experienceSettings,
      ),
      InferencePage(
        runtimeManager: _modelRuntimeManager,
        experienceSettings: _experienceSettings,
        onOpenModels: () => _selectPage(3),
      ),
      WorkHubPage(
        runtimeManager: _modelRuntimeManager,
        experienceSettings: _experienceSettings,
      ),
      LibraryHubPage(
        fileVerifier: _modelFileVerifier,
        runtimeManager: _modelRuntimeManager,
        experienceSettings: _experienceSettings,
      ),
    ];
  }

  void _selectPage(int index) {
    if (index == 4) {
      unawaited(_openDevices());
      return;
    }
    if (index < 0 || index >= _pages.length) {
      return;
    }
    setState(() {
      _visitedPages.add(index);
      _selectedIndex = index;
    });
  }

  Future<void> _openDevices() async {
    if (!mounted) {
      return;
    }
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => DevicesPage(
          service: _deviceNetworkService,
          runtimeManager: _modelRuntimeManager,
          experienceSettings: _experienceSettings,
        ),
      ),
    );
  }

  Future<void> _openMenuAction(_HomeMenuAction action) async {
    switch (action) {
      case _HomeMenuAction.toggleAdvanced:
        try {
          await _experienceSettings.toggle();
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(_experienceSettings.isAdvanced
                  ? 'تم تفعيل الخيارات المتطورة'
                  : 'تم إخفاء الخيارات المتطورة'),
            ),
          );
        } catch (error) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('تعذر حفظ التفضيل: $error')),
          );
        }
        return;
      case _HomeMenuAction.resourceSettings:
        Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => ResourceSettingsPage(
              isAdvanced: _experienceSettings.isAdvanced,
            ),
          ),
        );
        return;
      case _HomeMenuAction.privacy:
        Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => const PrivacyCenterPage(),
          ),
        );
        return;
    }
  }

  @override
  void dispose() {
    _modelRuntimeManager.dispose();
    _experienceSettings.dispose();
    unawaited(_deviceNetworkService.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final visiblePages = List<Widget>.generate(
      _pages.length,
      (index) => _visitedPages.contains(index)
          ? _pages[index]
          : const SizedBox.shrink(),
      growable: false,
    );

    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.hub_rounded, color: Color(0xFF0D9488)),
            const SizedBox(width: 10),
            const Text(
              'NEXUS AI',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                'Beta 1.6',
                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                      fontWeight: FontWeight.w700,
                    ),
              ),
            ),
          ],
        ),
        actions: [
          AnimatedBuilder(
            animation: _experienceSettings,
            builder: (context, _) => PopupMenuButton<_HomeMenuAction>(
              tooltip: 'الخيارات',
              onSelected: _openMenuAction,
              itemBuilder: (context) => [
                PopupMenuItem(
                  value: _HomeMenuAction.toggleAdvanced,
                  child: ListTile(
                    dense: true,
                    leading: Icon(_experienceSettings.isAdvanced
                        ? Icons.tune_rounded
                        : Icons.tune_outlined),
                    title: Text(_experienceSettings.isAdvanced
                        ? 'العودة للوضع البسيط'
                        : 'الخيارات المتطورة'),
                    subtitle: Text(_experienceSettings.isAdvanced
                        ? 'إخفاء التفاصيل التقنية'
                        : 'إظهار إعدادات المحرك والتخصيص'),
                  ),
                ),
                const PopupMenuItem(
                  value: _HomeMenuAction.resourceSettings,
                  child: ListTile(
                    dense: true,
                    leading: Icon(Icons.memory_rounded),
                    title: Text('طريقة الأداء'),
                  ),
                ),
                const PopupMenuItem(
                  value: _HomeMenuAction.privacy,
                  child: ListTile(
                    dense: true,
                    leading: Icon(Icons.privacy_tip_outlined),
                    title: Text('الخصوصية والبيانات'),
                  ),
                ),
              ],
              icon: const Icon(Icons.more_vert_rounded),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: IndexedStack(
          index: _selectedIndex,
          children: visiblePages,
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: _selectPage,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'الرئيسية',
          ),
          NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline_rounded),
            selectedIcon: Icon(Icons.chat_bubble_rounded),
            label: 'المحادثة',
          ),
          NavigationDestination(
            icon: Icon(Icons.task_alt_outlined),
            selectedIcon: Icon(Icons.task_alt_rounded),
            label: 'المهام',
          ),
          NavigationDestination(
            icon: Icon(Icons.library_books_outlined),
            selectedIcon: Icon(Icons.library_books_rounded),
            label: 'المكتبة',
          ),
          NavigationDestination(
            icon: Icon(Icons.devices_outlined),
            selectedIcon: Icon(Icons.devices_rounded),
            label: 'الأجهزة',
          ),
        ],
      ),
    );
  }
}
