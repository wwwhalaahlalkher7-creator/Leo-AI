import 'package:flutter_test/flutter_test.dart';
import 'package:material_ui/material_ui.dart';
import 'package:nexus_app/main.dart';
import 'package:nexus_app/src/features/inference/inference_page.dart';
import 'package:nexus_app/src/shared/retained_tab_host.dart';

class _CounterPage extends StatefulWidget {
  const _CounterPage({required this.name, super.key});

  final String name;

  @override
  State<_CounterPage> createState() => _CounterPageState();
}

class _CounterPageState extends State<_CounterPage> {
  int _count = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text('${widget.name} count: $_count'),
        FilledButton(
          onPressed: () => setState(() => _count++),
          child: Text('increment-${widget.name}'),
        ),
      ],
    );
  }
}

void _selectDestination(
  WidgetTester tester,
  Finder navigationFinder,
  int destination,
) {
  final onDestinationSelected =
      tester.widget<NavigationBar>(navigationFinder).onDestinationSelected;
  expect(onDestinationSelected, isNotNull);
  onDestinationSelected!(destination);
}

void main() {
  testWidgets('Beta shell retains the chat page when changing destinations',
      (tester) async {
    tester.view.physicalSize = const Size(432, 960);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await tester.pumpWidget(const NexusApp());
    await tester.pumpAndSettle();

    expect(find.text('Beta 1.6'), findsOneWidget);
    expect(find.text('تجهيز نموذج للبدء'), findsOneWidget);

    final navigationFinder = find.byType(NavigationBar);
    _selectDestination(tester, navigationFinder, 1);
    await tester.pumpAndSettle();

    expect(find.text('المحادثة المحلية'), findsOneWidget);
    expect(find.text('فتح النماذج'), findsOneWidget);
    final chatState = tester.state(find.byType(InferencePage));

    await tester.tap(find.text('فتح النماذج'));
    await tester.pumpAndSettle();
    expect(find.text('النماذج'), findsOneWidget);
    expect(find.text('المعرفة'), findsOneWidget);

    _selectDestination(tester, navigationFinder, 1);
    await tester.pumpAndSettle();

    _selectDestination(tester, navigationFinder, 0);
    await tester.pumpAndSettle();
    expect(find.text('مرحباً بك في NEXUS'), findsOneWidget);

    _selectDestination(tester, navigationFinder, 1);
    await tester.pumpAndSettle();

    expect(find.text('المحادثة المحلية'), findsOneWidget);
    expect(tester.state(find.byType(InferencePage)), same(chatState));
  });

  testWidgets('nested tabs create pages on demand and preserve visited state',
      (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: RetainedTabHost(
            tabs: const [Tab(text: 'A'), Tab(text: 'B')],
            pages: const [
              _CounterPage(name: 'A'),
              _CounterPage(name: 'B'),
            ],
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('B count: 0'), findsNothing);
    await tester.tap(find.text('B'));
    await tester.pumpAndSettle();
    expect(find.text('B count: 0'), findsOneWidget);

    await tester.tap(find.text('increment-B'));
    await tester.pumpAndSettle();
    expect(find.text('B count: 1'), findsOneWidget);

    await tester.tap(find.text('A'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('B'));
    await tester.pumpAndSettle();
    expect(find.text('B count: 1'), findsOneWidget);
  });
}
