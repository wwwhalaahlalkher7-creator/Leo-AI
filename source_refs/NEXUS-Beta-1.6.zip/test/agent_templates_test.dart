import 'package:flutter_test/flutter_test.dart';
import 'package:nexus_app/src/features/agents/agent_templates.dart';

void main() {
  test('starter templates have unique identities and valid local prompts', () {
    final templates = AgentStarterTemplates.all;
    final ids = templates.map((template) => template.id).toSet();

    expect(templates, hasLength(5));
    expect(ids, hasLength(templates.length));
    for (final template in templates) {
      expect(template.name.trim(), isNotEmpty);
      expect(template.description.trim(), isNotEmpty);
      expect(template.systemPrompt.trim(), isNotEmpty);
      expect(template.systemPrompt.length, lessThanOrEqualTo(3000));
      expect(template.systemPrompt, contains('لا تدّع'));
    }
  });
}
