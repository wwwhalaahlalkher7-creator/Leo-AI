import 'package:flutter_test/flutter_test.dart';
import 'package:nexus_app/src/features/agents/agent_record.dart';
import 'package:nexus_app/src/features/resources/nexus_smart_policy.dart';

AgentRecord _agent({
  required String id,
  required String name,
  required String description,
  AgentRecordStatus status = AgentRecordStatus.ready,
}) {
  return AgentRecord(
    id: id,
    name: name,
    description: description,
    status: status,
    createdAtUnixMs: 1,
  );
}

void main() {
  group('NexusSmartPolicy', () {
    test('uses local knowledge by default but respects advanced controls', () {
      expect(
        NexusSmartPolicy.shouldUseKnowledge(
          prompt: 'ماذا يوجد في ملفاتي؟',
          advancedMode: false,
          advancedKnowledgeEnabled: false,
        ),
        isTrue,
      );
      expect(
        NexusSmartPolicy.shouldUseKnowledge(
          prompt: 'ماذا يوجد في ملفاتي؟',
          advancedMode: true,
          advancedKnowledgeEnabled: false,
        ),
        isFalse,
      );
      expect(
        NexusSmartPolicy.shouldUseKnowledge(
          prompt: '/احسب 12 * 4',
          advancedMode: false,
          advancedKnowledgeEnabled: true,
        ),
        isFalse,
      );
    });

    test('chooses a goal-relevant ready planner and ignores paused agents', () {
      final general = _agent(
        id: 'general',
        name: 'المساعد العام',
        description: 'يساعد في الأسئلة اليومية',
      );
      final researcher = _agent(
        id: 'researcher',
        name: 'الباحث العلمي',
        description: 'تحليل المراجع والدراسات والمصادر العلمية',
      );
      final pausedProgrammer = _agent(
        id: 'paused',
        name: 'مبرمج',
        description: 'كتابة الشيفرات',
        status: AgentRecordStatus.paused,
      );

      final selected = NexusSmartPolicy.selectPlanner(
        goal: 'حلل المراجع العلمية وقارن الدراسات',
        agents: [general, researcher, pausedProgrammer],
      );
      expect(selected?.id, 'researcher');
    });

    test('falls back deterministically when no goal keywords match', () {
      final first = _agent(
        id: 'first',
        name: 'مساعد أول',
        description: 'مهام متنوعة',
      );
      final second = _agent(
        id: 'second',
        name: 'مساعد ثانٍ',
        description: 'عمل عام',
      );
      expect(
        NexusSmartPolicy.selectPlanner(
          goal: 'zxqv unmatchable token',
          agents: [first, second],
        )?.id,
        'first',
      );
      expect(
        NexusSmartPolicy.selectPlanner(goal: 'أي مهمة', agents: const []),
        isNull,
      );
    });
  });
}
