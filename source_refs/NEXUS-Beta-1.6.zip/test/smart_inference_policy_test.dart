import 'package:flutter_test/flutter_test.dart';
import 'package:nexus_app/src/features/resources/smart_inference_policy.dart';

void main() {
  group('SmartInferencePolicy', () {
    test('keeps short conversational replies concise by default', () {
      expect(
        SmartInferencePolicy.outputTokenBudget(
          prompt: 'ما عاصمة السودان؟',
          contextTokens: 4096,
        ),
        256,
      );
    });

    test('allocates more output for explicit detailed Arabic requests', () {
      expect(
        SmartInferencePolicy.outputTokenBudget(
          prompt: 'اشرح لي الفكرة باختصار',
          contextTokens: 4096,
        ),
        512,
      );
    });

    test('uses a larger budget for long prompts', () {
      expect(
        SmartInferencePolicy.outputTokenBudget(
          prompt: List.filled(70, 'سؤال طويل').join(' '),
          contextTokens: 4096,
        ),
        768,
      );
    });

    test('never exceeds one quarter of the loaded context or native ceiling', () {
      expect(
        SmartInferencePolicy.outputTokenBudget(
          prompt: 'اشرح بالتفصيل',
          contextTokens: 512,
        ),
        128,
      );
      expect(
        SmartInferencePolicy.outputTokenBudget(
          prompt: 'اكتب كوداً مفصلاً',
          contextTokens: 8192,
        ),
        1024,
      );
    });

    test('advanced manual override is still clamped safely', () {
      expect(
        SmartInferencePolicy.outputTokenBudget(
          prompt: 'إجابة قصيرة',
          contextTokens: 1024,
          manualOverride: 1024,
        ),
        256,
      );
      expect(
        SmartInferencePolicy.outputTokenBudget(
          prompt: 'إجابة قصيرة',
          contextTokens: 4096,
          manualOverride: 24,
        ),
        64,
      );
    });
  });
}
