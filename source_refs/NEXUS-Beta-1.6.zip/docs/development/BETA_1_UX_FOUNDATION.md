# NEXUS AI — Beta 1 UX foundation, guided setup and agent templates

## Goal

Reduce routine user interaction without reducing the platform's capabilities, local-first behavior, model/runtime safeguards, explicit device consent, or advanced controls.

## Included in this increment

- Reorganize the five primary destinations around the user's main jobs: Home, Chat, Tasks, Library, and Devices.
- Place task orchestration before agent configuration inside the Work area; keep agent management available as a peer tab.
- Group model management and local knowledge in one Library area, with separate tabs.
- Keep resource settings and privacy/data export available from a single overflow menu rather than occupying permanent app-bar actions.
- Keep visited top-level pages mounted using a lazy `IndexedStack`. This preserves active chat state and task state when switching destinations without eagerly constructing all feature pages on first launch.
- Use the same lazy, retained-tab behavior inside the Work and Library areas so the agent manager, task planner, model catalog, and knowledge library are created only when first opened and retain their page state afterward.
- Keep the Devices screen as a pushed route rather than a retained tab. Its existing `dispose` behavior continues to stop discovery/listening and clear approval handlers when the user leaves that screen.
- Replace the old static Alpha 1.9 dashboard claims with current, action-oriented information. Show model-session state first, a primary Chat action, shortcuts to Tasks/Library/Devices, and diagnostics in a collapsed section.
- Expose the Beta 1 milestone in the app shell, peer capability metadata, and Rust runtime diagnostics.

## Deliberately unchanged

- llama.cpp / Rust / Flutter Rust Bridge behavior and native C ABI.
- SQLite schema and user data.
- One active native model session, model/context limits, CPU inference, and GGUF support.
- Local tool allow-list, task planning/execution semantics, explicit approval gates, and peer cryptographic protocol.
- Resource modes and advanced configuration.

## Verification

Source-contract tests validate the new navigation labels, lazy page retention, route-based device lifecycle, accurate dashboard content, release version metadata, and unchanged Rust ABI version. Flutter analyze/tests, Rust tests/Clippy, Android ARM64 APK build, and physical-device acceptance remain mandatory CI/device gates; this source preparation does not claim those gates have passed.

## Remaining work in Beta 1

1. Verify navigation and state retention on-device, including switching away during active generation and returning to the chat.
2. Measure memory on a low-RAM device after visiting each destination; confirm lazy page construction avoids unnecessary startup work.
3. Review library/work tab layout and RTL behavior at narrow and large display widths.
4. Continue with streamlined task approval/execution, device overview improvements, and first-run recovery guidance in subsequent Beta increments.
5. Complete clean-install/upgrade, cancellation/recovery, offline, thermal, two-device, accessibility, and signed Release APK acceptance before a stable release.


## Beta 1.1 — Guided model setup (`2.9.0-beta.2+66`)

### Implemented in this source increment

- Empty Models library now offers direct single-file GGUF import; a user no longer has to create a catalog record and enter a model name first.
- A provisional local record is created only to provide a stable destination identifier for the existing transactional import pipeline. It is removed if the picker is cancelled or import fails.
- After successful GGUF inspection, the model display name is populated from GGUF metadata when available; the detected architecture, context and other metadata continue to be stored through the existing repository update.
- Manual catalog-only registration remains available as a secondary action.
- The dashboard's primary action is context-aware: open the model library to prepare/load a model when no session is active, or start a conversation when a model session is active.
- The chat model-status strip offers a direct route to the Library when no model is loaded.
- The Beta 1.1 package and peer capability versions are synchronized at `2.9.0-beta.2+66`. The Rust workspace version, native runtime stage, C ABI and SQLite schema v15 remain unchanged.

### Verification still required

- Flutter analyze and the complete widget/unit test suite.
- Rust tests, formatting and Clippy.
- Android ARM64 Debug APK build and physical-device import/load/chat acceptance.
- Test cancellation, invalid GGUF, low-storage failure and interrupted copy recovery on-device.
- Continue with first-run setup, agent templates and task approval improvements only after these gates pass.


## Beta 1.2 — Editable local agent templates (`2.9.0-beta.3+67`)

### Implemented in this source increment

- Added five Arabic starter personas: general assistant, researcher/analyst, tutor/reviewer, programming assistant, and writer/editor.
- The create-agent dialog displays the templates as selectable chips. Selecting one populates the existing name, description, and system-prompt fields; all fields remain editable before saving.
- A `من الصفر` action clears the fields and preserves the original custom-agent workflow.
- Every template is a prompt draft only. New agents remain `draft`, receive no model assignment, gain no new tool permissions, and are not made ready automatically.
- Template guidance explicitly says not to claim internet, file, or other access unless the runtime actually supplies it.
- Reused the existing `system_prompt` column. There is no SQLite migration, new dependency, peer protocol change, native C ABI change, or reduction to existing advanced controls.
- Added widget and data-contract tests for template population, editable/blank creation, draft status, unique template identifiers, prompt bounds, and local capability wording.
- Synchronized package and peer capability versions at `2.9.0-beta.3+67`; Rust workspace/ABI version remains `2.6.2`, runtime diagnostic stage remains unchanged, and database schema remains v15.

### Verification still required

- All Python source-contract/migration tests.
- Flutter analyze and the complete widget/unit test suite.
- Rust formatting, tests and Clippy (no Rust source changed in this increment).
- Android ARM64 development APK build and on-device testing of narrow RTL layouts, template selection, editing, saving, and the existing draft-to-ready/model-assignment flow.
- Final signed Release APK and clean-install/upgrade acceptance remain deferred until feature development is complete.


## Beta 1.3 — Agent setup stability (`2.9.0-beta.4+68`)

- Replaced create-dialog `TextEditingController` ownership with keyed `TextFormField.initialValue` fields and local form state. This avoids controller lifecycle races with the dialog route's reverse transition.
- Template application updates name, description, and system instructions as one revision; edits made after applying a template are persisted in the resulting draft.
- Replaced the instruction editor's controller with local form state for the same lifecycle guarantee.
- Made the empty-agent state vertically scrollable and constrained to available viewport height for short screens, larger text settings, and keyboard/inset changes.
- Updated package/peer capability version to `2.9.0-beta.4+68`; Rust workspace/ABI version and SQLite schema v15 remain unchanged.
- Flutter widget tests and Android build must still be confirmed by GitHub Actions; local verification here covers Python contracts and source consistency only.


## Beta 1.4 — Explicit agent readiness (`2.9.0-beta.5+69`)

### Implemented in this source increment

- Moving a draft or paused agent to `ready` now opens a concise readiness review before changing its status.
- If the agent has a model assignment, the app reloads the current model record and verifies that it is still an installed local `llama.cpp` model with a non-empty path, then re-runs the existing local model-file audit. Missing, uninstalled, unsupported, or invalid assigned models block the transition and leave the agent unchanged.
- If no model is assigned, the review explains whether an active session currently exists and that the user must load a model before inference when no session is active. This remains an allowed configuration because chat can use the shared active model.
- The confirmation states that `ready` only makes the agent available to chat/task workflows; it does not load a model, start inference, execute a task, or grant new tools.
- Draft/paused cards now show a direct `تجهيز الوكيل` / `إعادة التجهيز` action; the overflow action remains available.
- Added widget coverage for the readiness review, the no-assigned-model path, and blocking activation when an assigned model fails the file audit.
- Synchronized Flutter package and peer capability versions at `2.9.0-beta.5+69`; Rust workspace/ABI version remains `2.6.2`, and SQLite schema remains v15.

### Verification still required

- Run all Python source-contract and migration suites.
- Run Flutter analyze and the complete widget/unit test suite in GitHub Actions.
- Run Rust format, tests, and Clippy; no Rust source changed in this increment.
- Build the Android ARM64 development APK and verify model assignment loss/corruption and the readiness flow on a physical device.
- Signed Release APK and final clean-install/upgrade acceptance remain deferred until feature development is complete.


## Beta 1.5 — Editable orchestration plan review (`2.9.0-beta.6+70`)

### Implemented in this source increment

- Added an explicit edit action to each generated plan step before saving. Users can revise the objective and expected output and reassign the step to any currently ready agent.
- Kept step IDs and dependency edges immutable in the editor; the helper returns a new immutable plan and rejects identity/dependency changes.
- Added a compact review summary with step count, distinct assigned-agent count, and a clear statement that execution is sequential on one local model session, without automatic loading or parallel execution.
- Re-loads the agent catalog immediately before saving and validates the edited plan again. A step assigned to an agent that was paused, deleted, or otherwise became unavailable cannot be persisted.
- Added unit tests for immutable replacement, preserving dependency edges, and rejecting identity/dependency mutation.
- Synchronized package and peer capability versions at `2.9.0-beta.6+70`; Rust workspace/ABI version remains `2.6.2`, and SQLite schema remains v15.

### Verification still required

- Run all Python source-contract and migration suites.
- Run Flutter analyze and the complete widget/unit test suite in GitHub Actions.
- Run Rust formatting, tests and Clippy; no Rust source changed in this increment.
- Build the Android ARM64 development APK and verify editing/reassignment, stale-agent rejection, RTL layout, and long plan behavior on a physical device.
- Signed Release APK and final clean-install/upgrade acceptance remain deferred until feature development is complete.


## Beta 1.6 — Smart, simple everyday experience (`2.9.0-beta.7+71`)

### Implemented in this source increment

- Added a persisted presentation preference in the existing `app_settings` table. New installs default to Basic mode; changing the presentation level does not alter tool permissions or remote-device approval rules.
- Added `NexusSmartPolicy` as a small decision facade over existing policies. It selects safe runtime context/thread recommendations, chooses a bounded output-token budget from the current prompt/context, decides whether local knowledge retrieval applies, and selects a ready task planner by matching goal words against local agent metadata.
- Basic chat uses automatic output length (64–1,024 tokens, further capped to one quarter of the active context) and local BM25 knowledge retrieval. Advanced mode retains the manual output override and knowledge toggle.
- Basic model import performs the existing file verification, fit estimation, runtime preparation, and load flow automatically. A memory estimate that is insufficient or unknown still presents a confirmation; changing an already-loaded model/session still requires confirmation. Advanced mode retains the full review dialog and manual load control.
- Basic mode hides CPU/context/model metadata, raw network addresses, invitation secrets, manual IP/port pairing, benchmark controls, and planner/resource details. These remain available in Advanced Options.
- Device discovery begins automatically when the Devices screen opens, using the pre-existing bounded 30-second service window. Device identity verification, pairing approval, and remote task execution approval are unchanged.
- Basic task planning chooses a ready planner automatically, presents a simpler task flow, then asks the user to confirm execution. The advanced path retains planner selection and editable plan review.
- Added unit tests for prompt-aware output budgeting and Battery Saver policy limits; no third-party package was added.
- Flutter package and peer capability versions advance to `2.9.0-beta.7+71`; Rust workspace/native ABI remains `2.6.2`, and SQLite schema remains v15.

### Verification still required

- Run the Python source-contract and migration suites.
- Run `dart format`, `flutter analyze`, and the complete Flutter unit/widget test suite in CI.
- Run Rust formatting/tests/Clippy and build the Android ARM64 development APK; no Rust or C++ source changed in this increment.
- On a physical device, validate basic-mode model import/auto-load, low-memory confirmation, battery/thermal adaptation, long response continuation, automatic BM25 retrieval, device discovery timeout, QR pairing, and the explicit remote execution approval path.
- Verify that Advanced Options persists across restarts and that switching modes while pages remain mounted updates all relevant screens.
- Signed Release APK and final clean-install/upgrade acceptance remain deferred until feature development is complete.
