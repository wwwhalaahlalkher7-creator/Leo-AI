# Alpha 2.8.3 — Rust type inference repair

## Failure addressed
Android ARM64 Cargokit compilation failed in `core/runtime/src/native/engine.rs` while collecting `CString` role/content pairs. Rust could not infer the error type for the closure's `Ok((...))` because `?` left the conversion target ambiguous.

## Change
The collected result now explicitly declares `std::ffi::NulError` as its error type. This matches both `CString::new` calls and preserves the existing NUL-character rejection path and user-facing error message. No FFI layout, inference behavior, model lifecycle, or Gradle/NDK settings were changed.

## Version
Flutter package version: `2.8.3+64`. The Rust workspace version is intentionally unchanged.

## Verification status
Source-level assertion and archive integrity are checked during packaging. Flutter analyze/tests, Rust target compilation, Android NDK build, and device execution must still be verified by CI/device; this environment does not provide the project's Android build toolchain.
