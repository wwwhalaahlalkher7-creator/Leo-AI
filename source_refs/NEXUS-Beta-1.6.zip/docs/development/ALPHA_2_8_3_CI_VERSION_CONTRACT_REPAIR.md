# Alpha 2.8.3 — CI version-contract repair

Package version: `2.8.3+64`

## Changes

- Incremented the Flutter package build metadata from `2.8.3+63` to `2.8.3+64`.
- Updated peer capability snapshots to advertise app semantic version `2.8.3`.
- Updated the privacy-center and dependency-compatibility source contracts to validate the current package version.
- Kept the Rust workspace version at `2.6.2`; no native C ABI symbol, signature, or SQLite schema was changed by this repair.
- Retained the explicit `std::ffi::NulError` annotation in the native Rust message conversion path from the preceding Rust compiler repair.

## Verification status

The previous CI log reported the host fake-llama C ABI contract and the listed migration/feature contracts as passing. The only reported failure was the stale package-version assertion in the privacy-center contract. This source repair aligns the package metadata, peer metadata, and assertions. The full Python source-contract suite, Flutter analyze/tests, Rust checks, Android ARM64 APK build, and physical-device smoke test must still pass in CI; this document does not claim those runs have completed.
