#!/usr/bin/env python3
"""Source contracts for the first NEXUS Beta UX foundation."""
from pathlib import Path
import re
import yaml

ROOT = Path(__file__).resolve().parents[1]
app = (ROOT / "lib/src/app.dart").read_text(encoding="utf-8")
dashboard = (ROOT / "lib/src/features/dashboard/dashboard_page.dart").read_text(encoding="utf-8")
library = (ROOT / "lib/src/features/library/library_hub_page.dart").read_text(encoding="utf-8")
work = (ROOT / "lib/src/features/work/work_hub_page.dart").read_text(encoding="utf-8")
retained_tabs = (ROOT / "lib/src/shared/retained_tab_host.dart").read_text(encoding="utf-8")
devices = (ROOT / "lib/src/features/devices/devices_page.dart").read_text(encoding="utf-8")
readme = (ROOT / "README.md").read_text(encoding="utf-8")
pubspec = yaml.safe_load((ROOT / "pubspec.yaml").read_text(encoding="utf-8"))
peer = (ROOT / "lib/src/features/devices/device_network_service.dart").read_text(encoding="utf-8")
runtime = (ROOT / "core/runtime/src/lib.rs").read_text(encoding="utf-8")
rust_manifest = (ROOT / "Cargo.toml").read_text(encoding="utf-8")
database = (ROOT / "lib/src/data/local_database.dart").read_text(encoding="utf-8")

version = str(pubspec["version"])
semantic_version, build_number = version.split("+", 1)

checks = {
    "Beta 1 package version and peer capability version agree": (
        semantic_version == "2.9.0-beta.7"
        and build_number == "71"
        and "'app_version': '2.9.0-beta.7'" in peer
    ),
    "Rust workspace and native ABI version remain unchanged": (
        re.search(r'(?m)^version = "2\.6\.2"$', rust_manifest) is not None
    ),
    "runtime diagnostics report Beta 1 rather than a stale Alpha milestone": (
        'stage: "beta-1-ui-foundation"' in runtime
        and "alpha-2.7.6-explainable-placement" not in runtime
    ),
    "five primary destinations are organized around user tasks": all(
        item in app for item in (
            "label: 'الرئيسية'", "label: 'المحادثة'", "label: 'المهام'",
            "label: 'المكتبة'", "label: 'الأجهزة'",
        )
    ) and app.count("NavigationDestination(") == 5,
    "visited main pages remain mounted without eagerly creating untouched pages": (
        "final Set<int> _visitedPages = <int>{0}" in app
        and "_visitedPages.add(index)" in app
        and "IndexedStack(" in app
        and "_visitedPages.contains(index)" in app
        and "const SizedBox.shrink()" in app
    ),
    "devices stay route-based and stop discovery/listening when closed": (
        "DevicesPage(" in app
        and "MaterialPageRoute<void>(" in app
        and "IndexedStack(" in app
        and "unawaited(widget.service.stopDiscovery())" in devices.split("void dispose()", 1)[1].split("Widget build(BuildContext context)", 1)[0]
        and "unawaited(widget.service.stopListening())" in devices.split("void dispose()", 1)[1].split("Widget build(BuildContext context)", 1)[0]
    ),
    "the Work area groups tasks before agent configuration": (
        "AgentTasksPage(" in work and "experienceSettings: experienceSettings" in work
        and "AgentsPage(" in work
        and "showTaskNavigationAction: false" in work
        and "RetainedTabHost(" in work
    ),
    "the Library area preserves separate model and knowledge workspaces": (
        "ModelsPage(" in library and "KnowledgePage()" in library
        and "RetainedTabHost(" in library
    ),
    "nested tabs also defer unopened pages and retain visited page state": (
        "_visitedPages = <int>{widget.initialIndex}" in retained_tabs
        and "_visitedPages.add(index)" in retained_tabs
        and "IndexedStack(" in retained_tabs
        and "_visitedPages.contains(index)" in retained_tabs
    ),
    "dashboard prioritizes current model state and user actions": all(
        item in dashboard for item in (
            "_ModelSessionSummary", "ابدأ محادثة", "تجهيز نموذج للبدء", "تنفيذ مهمة متعددة الوكلاء",
            "النماذج والمعرفة", "الأجهزة المتصلة", "تفاصيل المحرك والتشخيص",
        )
    ) and "Alpha 1.9" not in dashboard
    and "دون تنفيذ مهام AI بعد" not in dashboard
    and "ضمن مرحلة لاحقة" not in dashboard,
    "GGUF import can start without manually creating a model record": (
        "Future<void> _importNewModel()" in (ROOT / "lib/src/features/models/models_page.dart").read_text(encoding="utf-8")
        and "onPressed: _creatingImport ? null : _importNewModel" in (ROOT / "lib/src/features/models/models_page.dart").read_text(encoding="utf-8")
        and "displayName: displayName" in (ROOT / "lib/src/features/models/models_page.dart").read_text(encoding="utf-8")
    ),
    "chat empty model state links directly to the model library": (
        "onOpenModels" in (ROOT / "lib/src/features/inference/inference_page.dart").read_text(encoding="utf-8")
        and "onOpenModels: () => _selectPage(3)" in app
    ),
    "agent readiness checks an assigned local model before status activation": all(
        token in (ROOT / "lib/src/features/agents/agents_page.dart").read_text(encoding="utf-8")
        for token in (
            "Future<void> _prepareAgent(AgentRecord agent)",
            "_modelFileVerifier.verify(model)",
            "model.status != ModelInstallStatus.installed",
            "لا يمكن تجهيز الوكيل",
        )
    ),
    "agent readiness explicitly prevents implicit inference and tool grants": all(
        token in (ROOT / "lib/src/features/agents/agents_page.dart").read_text(encoding="utf-8")
        for token in (
            "لن يتم تحميل نموذج أو بدء استدلال",
            "أو منح أدوات جديدة تلقائياً",
            "تجهيز الوكيل",
        )
    ),
    "Beta 1.5 editable task review preserves identity and dependencies": all(
        token in (ROOT / "lib/src/features/orchestration/agent_task_plan.dart").read_text(encoding="utf-8")
        for token in ("replaceAgentTaskPlanStep", "replacement.id !=", "replacement.dependsOn")
    ) and all(
        token in (ROOT / "lib/src/features/orchestration/agent_tasks_page.dart").read_text(encoding="utf-8")
        for token in ("_editDraftStep", "تعديل الخطوة", "التنفيذ بالتتابع", "currentAgents = await _agentsRepository.list()")
    ),
    "Beta 1.5 does not add a SQLite migration": "_databaseVersion = 15" in database,
    "Beta 1.4 scope and remaining acceptance are documented": (
        "Beta 1" in readme
        and "docs/development/BETA_1_UX_FOUNDATION.md" in readme
        and "Remaining acceptance work before Beta 1 can be considered stable" in readme
    ),
}

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'} {name}")
if failed:
    raise SystemExit("Beta 1 UX contract failures: " + ", ".join(failed))
print(f"Beta 1 UX contract PASS: {len(checks)} checks")
