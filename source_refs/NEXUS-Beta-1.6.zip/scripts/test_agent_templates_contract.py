#!/usr/bin/env python3
"""Source contracts for editable, local-only agent starter templates."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
templates = (ROOT / "lib/src/features/agents/agent_templates.dart").read_text(encoding="utf-8")
page = (ROOT / "lib/src/features/agents/agents_page.dart").read_text(encoding="utf-8")
repository = (ROOT / "lib/src/features/agents/agent_repository.dart").read_text(encoding="utf-8")
database = (ROOT / "lib/src/data/local_database.dart").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/ci.yml").read_text(encoding="utf-8")

checks = {
    "five Arabic starter roles are present": all(
        name in templates for name in (
            "مساعد عام", "باحث ومحلل", "مدرس ومراجع", "مساعد برمجي", "كاتب ومحرر"
        )
    ),
    "templates are immutable data and do not modify runtime state": (
        "class AgentStarterTemplate" in templates
        and "static const List<AgentStarterTemplate> all" in templates
        and "do not enable agents" in templates
    ),
    "the creation dialog lets users apply and edit a template": (
        "AgentStarterTemplates.all" in page
        and "_applyTemplate" in page
        and "ChoiceChip(" in page
        and "من الصفر" in page
    ),
    "template choices populate keyed editable fields without controller ownership": all(
        token in page for token in (
            "_name = template.name",
            "_description = template.description",
            "_systemPrompt = template.systemPrompt",
            "ValueKey('agent-name-$_fieldRevision')",
            "ValueKey('agent-description-$_fieldRevision')",
            "ValueKey('agent-prompt-$_fieldRevision')",
        )
    ) and "TextEditingController" not in page,
    "new template agents remain drafts without an implicit model assignment": (
        "status: AgentRecordStatus.draft" in page
        and "modelId:" not in page.split("Future<void> _createAgent()", 1)[1].split("Future<void> _editInstructions", 1)[0]
    ),
    "template support uses the existing system prompt store and imposes no new schema": (
        "system_prompt" in repository
        and "_databaseVersion = 15" in database
        and "ALTER TABLE agents" not in templates
    ),
    "templates do not pretend to grant file or network access": all(
        token in templates for token in (
            "لا تدّعِ تصفح الإنترنت",
            "لا تدّعِ الوصول إلى الشبكة",
            "لا تفترض وجود اتصال شبكة أو وصول إلى ملفات",
        )
    ),
    "create and instruction dialogs avoid disposed-controller races": (
        "onChanged: (value) => _name = value" in page
        and "onChanged: (value) => _systemPrompt = value" in page
        and "onChanged: (value) => _value = value" in page
        and "TextEditingController" not in page
    ),
    "empty agent state remains scrollable on compact viewports": (
        "if (agents.isEmpty)" in page
        and "SingleChildScrollView(" in page
        and "(constraints.maxHeight - 48).clamp(0.0, double.infinity).toDouble()" in page
    ),
    "GitHub Actions executes this new source contract": "python3 scripts/test_agent_templates_contract.py" in workflow,
}

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'} {name}")
if failed:
    raise SystemExit("Agent template contract failures: " + ", ".join(failed))
print(f"Agent template contract PASS: {len(checks)} checks")
