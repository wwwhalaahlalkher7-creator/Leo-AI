#!/usr/bin/env python3
"""Source contracts for Beta 1.6's zero-configuration user experience."""
from pathlib import Path
import re
import yaml

ROOT = Path(__file__).resolve().parents[1]
app = (ROOT / "lib/src/app.dart").read_text(encoding="utf-8")
experience = (ROOT / "lib/src/features/resources/nexus_experience_settings.dart").read_text(encoding="utf-8")
smart = (ROOT / "lib/src/features/resources/nexus_smart_policy.dart").read_text(encoding="utf-8")
inference = (ROOT / "lib/src/features/inference/inference_page.dart").read_text(encoding="utf-8")
models = (ROOT / "lib/src/features/models/models_page.dart").read_text(encoding="utf-8")
tasks = (ROOT / "lib/src/features/orchestration/agent_tasks_page.dart").read_text(encoding="utf-8")
devices = (ROOT / "lib/src/features/devices/devices_page.dart").read_text(encoding="utf-8")
resource_page = (ROOT / "lib/src/features/resources/resource_settings_page.dart").read_text(encoding="utf-8")
database = (ROOT / "lib/src/data/local_database.dart").read_text(encoding="utf-8")
pubspec = yaml.safe_load((ROOT / "pubspec.yaml").read_text(encoding="utf-8"))
network = (ROOT / "lib/src/features/devices/device_network_service.dart").read_text(encoding="utf-8")

version = str(pubspec["version"])
semantic, build = version.split("+", 1)

checks = {
    "basic experience is the default and preference uses existing app settings": (
        "bool _advanced = false" in experience
        and "nexus_advanced_options_enabled" in experience
        and "'app_settings'" in experience
        and "unawaited(_experienceSettings.load())" in app
        and "experienceSettings: _experienceSettings" in app
    ),
    "advanced options are persisted through one app-shell toggle": (
        "_HomeMenuAction.toggleAdvanced" in app
        and "await _experienceSettings.toggle()" in app
        and "الخيارات المتطورة" in app
    ),
    "central smart policy covers generation, knowledge, runtime, and planner decisions": all(
        token in smart for token in (
            "outputTokenBudget", "shouldUseKnowledge", "recommendRuntime", "selectPlanner"
        )
    ),
    "normal chat uses adaptive output budget and automatic local knowledge retrieval": (
        "NexusSmartPolicy.outputTokenBudget" in inference
        and "NexusSmartPolicy.shouldUseKnowledge" in inference
        and "advancedMode: _isAdvanced" in inference
    ),
    "advanced chat retains output override and knowledge toggle": (
        "if (_isAdvanced)" in inference
        and "advancedOverride:" in inference
        and "FilterChip(" in inference
    ),
    "basic model import automatically fits and loads the verified installed record": (
        "if (!_isAdvanced)" in models
        and "final installed = (await _store.list()).firstWhere(" in models
        and "await _estimateModelFit(installed)" in models
        and "result = await _runtimeManager.loadPrepared(model)" in models
    ),
    "unknown or insufficient memory still requires explicit confirmation": (
        "ModelFitStatus.insufficient" in models
        and "ModelFitStatus.tight" in models
        and "ModelFitStatus.unknown" in models
        and "showDialog<bool>" in models
        and "سيعيد المحرك التحقق قبل التحميل" in models
    ),
    "basic tasks select a goal-relevant planner automatically and preserve execution approval": (
        "NexusSmartPolicy.selectPlanner" in tasks
        and "_savePlan(runAfterSave: !_isAdvanced)" in tasks
        and "showDialog<bool>" in tasks
        and "تنفيذ خطة الوكلاء؟" in tasks
    ),
    "nearby discovery starts automatically using the existing bounded service": (
        "await widget.service.startDiscovery()" in devices
        and "widget.service.isDiscovering" in devices
        and "Duration(seconds: 30)" in (ROOT / "lib/src/features/devices/device_network_service.dart").read_text(encoding="utf-8")
    ),
    "basic device connection hides manual address and secret fields but retains QR": (
        "if (_isAdvanced) ...[" in devices
        and "_scanQrInvite" in devices
        and "_pasteQrInvite" in devices
        and "if (_isAdvanced)" in devices
    ),
    "unrestricted resource posture is visible only in advanced mode": (
        "widget.isAdvanced || mode != ResourceMode.unrestricted" in resource_page
    ),
    "existing tool and peer approvals remain in place": (
        "approvalHandler: _approvePeerTaskExecution" in devices
        and "PeerTaskExecutionApproval" in devices
        and "موافقة وتنفيذ" in devices
        and "تنفيذ خطة الوكلاء؟" in tasks
    ),
    "no SQLite schema migration or new package dependency is introduced": (
        "_databaseVersion = 15" in database
    ),
    "Beta 1.6 app and peer capability versions are synchronized": (
        semantic == "2.9.0-beta.7"
        and build == "71"
        and "'app_version': '2.9.0-beta.7'" in network
        and re.search(r'(?m)^version = "2\.6\.2"$', (ROOT / "Cargo.toml").read_text(encoding="utf-8")) is not None
    ),
}

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'} {name}")
if failed:
    raise SystemExit("Beta 1.6 smart-mode contract failures: " + ", ".join(failed))
print(f"Beta 1.6 smart-mode contract PASS: {len(checks)} checks")
