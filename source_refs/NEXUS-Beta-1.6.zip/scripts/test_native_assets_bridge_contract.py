#!/usr/bin/env python3
"""Guard the Rust bridge Native Assets packaging contract."""
from pathlib import Path
import tomllib
import yaml

ROOT = Path(__file__).resolve().parents[1]
pubspec = yaml.safe_load((ROOT / "pubspec.yaml").read_text(encoding="utf-8"))
dependencies = pubspec["dependencies"]
hook = (ROOT / "hook/build.dart").read_text(encoding="utf-8")
integration = (ROOT / "scripts/integrate_bridge.sh").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/ci.yml").read_text(encoding="utf-8")
bridge_manifest = tomllib.loads((ROOT / "core/bridge/Cargo.toml").read_text(encoding="utf-8"))
toolchain = tomllib.loads((ROOT / "rust-toolchain.toml").read_text(encoding="utf-8"))

checks = {
    "FRB hooks dependency is pinned to the bridge generator version": dependencies.get("flutter_rust_bridge_hooks") == "2.13.0",
    "legacy Cargokit plugin dependency is removed": "rust_lib_nexus_app" not in dependencies and "rust_builder" not in pubspec.get("dependencies", {}),
    "Native Assets hook invokes the FRB builder": "FlutterRustBridgeNativeAssetsBuilder(" in hook,
    "Native Assets hook points to the actual bridge crate": "cratePath: 'core/bridge'" in hook,
    "Native Assets hook associates the generated Dart FFI loader": "assetName: 'src/rust/frb_generated.io.dart'" in hook,
    "Native Assets hook explicitly routes the library into the app bundle": "ToAppBundle()" in hook,
    "Rust bridge produces both static and dynamic libraries": set(bridge_manifest["lib"]["crate-type"]) >= {"cdylib", "staticlib"},
    "Rust build toolchain is pinned to a concrete release": toolchain["toolchain"]["channel"] == "1.100.0",
    "Android ARM64 target is installed by the pinned toolchain": "aarch64-linux-android" in toolchain["toolchain"]["targets"],
    "local integration uses the Native Assets backend": "--integration-backend native-assets" in integration and "--integration-backend cargokit" not in integration,
    "CI uses the Native Assets backend": "--integration-backend native-assets" in workflow and "--integration-backend cargokit" not in workflow,
    "CI blocks APKs without the Rust bridge shared library": "lib/arm64-v8a/libnexus_bridge.so" in workflow,
}

failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'} {name}")
if failed:
    raise SystemExit("Native Assets bridge contract failures: " + ", ".join(failed))
print(f"Native Assets bridge contract PASS: {len(checks)} checks")
